@echo off
echo ==========================================
echo   NXANCE - Starting Backend
echo ==========================================
echo.
echo Installing packages (first time only)...
pip install fastapi uvicorn requests scipy numpy pandas openpyxl python-multipart anthropic
echo.
echo Starting Nxance...
echo Open browser: http://localhost:8000
echo.
python main.py
pause
