"""
Nxance Backend - Complete
Real AMFI data + Real engines + Complete API

Run: python main.py
Open: http://localhost:8000
"""

from fastapi import FastAPI, HTTPException, UploadFile, File
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import Optional, List
import requests, json, os, io, math, time
from datetime import date, datetime, timedelta
from scipy.optimize import brentq, minimize
import numpy as np
import pandas as pd
import uvicorn

app = FastAPI(title="Nxance", version="1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

# ═══════════ CACHE ═══════════
_C = {}
_CT = {}

def fresh(k, h=6):
    return k in _CT and (datetime.now()-_CT[k]).seconds < h*3600

def cset(k, v):
    _C[k]=v; _CT[k]=datetime.now(); return v

def cget(k): return _C.get(k)

# ═══════════ REAL AMFI DATA ═══════════
def amfi_search(q):
    k=f"s_{q}"
    if fresh(k,1): return cget(k)
    try:
        r=requests.get("https://api.mfapi.in/mf/search",params={"q":q},timeout=10)
        if r.status_code==200: return cset(k,r.json()[:15])
    except: pass
    return []

def amfi_nav(code):
    k=f"n_{code}"
    if fresh(k,6): return cget(k)
    try:
        r=requests.get(f"https://api.mfapi.in/mf/{code}",timeout=15)
        if r.status_code==200:
            d=r.json()
            if d.get("data"): return cset(k,d)
    except: pass
    return None

def nav_latest(code):
    d=amfi_nav(code)
    if not d: return None,None
    e=d["data"][0]
    return float(e["nav"]),e["date"]

def nav_on_date(code, tdate):
    d=amfi_nav(code)
    if not d: return None
    for e in reversed(d["data"]):
        try:
            ed=datetime.strptime(e["date"],"%d-%m-%Y").date()
            if ed<=tdate: return float(e["nav"])
        except: pass
    return float(d["data"][-1]["nav"]) if d["data"] else None

# ═══════════ REAL STOCK DATA ═══════════
YF_HDR={"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0","Accept":"application/json","Referer":"https://finance.yahoo.com"}

def stock_price(sym):
    k=f"sp_{sym}"
    if fresh(k,0.5): return cget(k)
    for base in ["https://query1.finance.yahoo.com","https://query2.finance.yahoo.com"]:
        try:
            r=requests.get(f"{base}/v8/finance/chart/{sym}?interval=1d&range=5d",headers=YF_HDR,timeout=10)
            if r.status_code==200:
                p=r.json()["chart"]["result"][0]["meta"]["regularMarketPrice"]
                if p: return cset(k,round(float(p),2))
        except: pass
    return None

def stock_hist(sym,days=365):
    k=f"sh_{sym}_{days}"
    if fresh(k,2): return cget(k)
    s=int((datetime.now()-timedelta(days=days)).timestamp())
    e=int(datetime.now().timestamp())
    try:
        r=requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?interval=1d&period1={s}&period2={e}",headers=YF_HDR,timeout=15)
        if r.status_code==200:
            res=r.json()["chart"]["result"][0]
            ts=res.get("timestamp",[])
            cl=res["indicators"]["quote"][0].get("close",[])
            hist=[{"date":datetime.fromtimestamp(t).date().isoformat(),"close":round(float(c),2)} for t,c in zip(ts,cl) if c]
            return cset(k,hist)
    except: pass
    return []

# ═══════════ TER DATABASE (AMFI sourced) ═══════════
TER={
    "axis bluechip":{"r":1.54,"d":0.47},"axis midcap":{"r":1.88,"d":0.55},
    "axis small cap":{"r":1.89,"d":0.56},"axis flexicap":{"r":1.62,"d":0.50},
    "axis long term equity":{"r":1.65,"d":0.52},
    "mirae asset large cap":{"r":1.52,"d":0.52},"mirae asset emerging bluechip":{"r":1.65,"d":0.62},
    "parag parikh flexi cap":{"r":1.71,"d":0.66},"parag parikh":{"r":1.71,"d":0.66},
    "hdfc top 100":{"r":1.68,"d":0.98},"hdfc flexi cap":{"r":1.68,"d":0.98},
    "hdfc midcap":{"r":1.72,"d":0.72},"hdfc small cap":{"r":1.75,"d":0.75},
    "hdfc balanced advantage":{"r":1.67,"d":0.88},
    "hdfc nifty 50":{"r":0.20,"d":0.10},"hdfc nifty":{"r":0.20,"d":0.10},
    "hdfc short duration":{"r":0.85,"d":0.28},"hdfc liquid":{"r":0.45,"d":0.20},
    "icici pru bluechip":{"r":1.56,"d":0.98},"icici pru value":{"r":1.62,"d":0.99},
    "icici pru balanced":{"r":1.62,"d":0.98},"icici pru nifty":{"r":0.18,"d":0.09},
    "sbi bluechip":{"r":1.62,"d":0.83},"sbi small cap":{"r":1.73,"d":0.70},
    "sbi equity hybrid":{"r":1.59,"d":0.87},"sbi contra":{"r":1.62,"d":0.87},
    "kotak emerging equity":{"r":1.89,"d":0.55},"kotak flexicap":{"r":1.62,"d":0.62},
    "kotak small cap":{"r":1.85,"d":0.58},"kotak nifty":{"r":0.22,"d":0.11},
    "nippon india small cap":{"r":1.78,"d":0.78},"nippon india large cap":{"r":1.65,"d":0.78},
    "nippon india liquid":{"r":0.35,"d":0.16},"nippon india gold":{"r":0.55,"d":0.20},
    "nippon india index":{"r":0.20,"d":0.10},"nippon india nifty":{"r":0.20,"d":0.10},
    "uti nifty 50":{"r":0.20,"d":0.10},"uti nifty next":{"r":0.35,"d":0.15},
    "quant small cap":{"r":0.64,"d":0.62},"quant active":{"r":0.63,"d":0.58},
    "quant tax":{"r":0.63,"d":0.58},
    "motilal oswal nasdaq":{"r":0.65,"d":0.58},"motilal oswal s&p":{"r":0.65,"d":0.45},
    "motilal oswal nifty":{"r":0.20,"d":0.10},
    "dsp midcap":{"r":1.65,"d":0.68},"canara rob bluechip":{"r":1.60,"d":0.47},
    "franklin india bluechip":{"r":1.75,"d":0.88},
    "aditya birla frontline":{"r":1.87,"d":0.96},"aditya birla":{"r":1.87,"d":0.96},
    "nifty 50 index":{"r":0.20,"d":0.10},"nifty index":{"r":0.20,"d":0.10},
}

def get_ter(name, plan):
    n=name.lower()
    for k,v in TER.items():
        if k in n: return v.get("d" if "direct" in plan.lower() else "r",1.55)
    # detect type
    if any(w in n for w in ["liquid","overnight","money market"]): return 0.20 if "direct" in plan.lower() else 0.45
    if any(w in n for w in ["index","nifty","sensex"]): return 0.12 if "direct" in plan.lower() else 0.22
    if any(w in n for w in ["debt","bond","gilt","duration"]): return 0.30 if "direct" in plan.lower() else 0.85
    return 0.50 if "direct" in plan.lower() else 1.55

# ═══════════ FUND HOLDINGS (for overlap) ═══════════
FH={
"axis bluechip":["HDFC Bank","Infosys","Reliance","ICICI Bank","TCS","Kotak MB","Bajaj Finance","HUL","Asian Paints","Maruti","Titan","L&T","Nestle","Sun Pharma","Wipro","HCL Tech","Bajaj Auto","Pidilite","Mphasis","Persistent","Berger Paints","Marico","Britannia","Godrej Consumer","Tata Consumer","Crompton","Divi Lab","Avenue Supermarts","HDFC Life","ICICI Lombard"],
"mirae large":["HDFC Bank","Infosys","Reliance","ICICI Bank","TCS","Kotak MB","Axis Bank","L&T","Bharti Airtel","ITC","HCL Tech","Bajaj Finance","SBI","HUL","Asian Paints","Maruti","Sun Pharma","Titan","Ultratech","M&M","Power Grid","NTPC","Tata Motors","Wipro","Bajaj Auto","Eicher Motors","Tata Steel","Cipla","Dr Reddy","Tech Mahindra"],
"sbi bluechip":["HDFC Bank","Infosys","ICICI Bank","Reliance","TCS","L&T","Kotak MB","Axis Bank","HUL","ITC","Bajaj Finance","Sun Pharma","Asian Paints","Maruti","Titan","HCL Tech","Bharti Airtel","Nestle","SBI","Tata Motors","M&M","Power Grid","Ultratech","NTPC","Bajaj Auto","Wipro","Tech Mahindra","Adani Enterprises"],
"hdfc flexi":["HDFC Bank","ICICI Bank","Infosys","Reliance","Axis Bank","Bharti Airtel","SBI","ITC","Kotak MB","L&T","Bajaj Finance","Sun Pharma","HCL Tech","TCS","Maruti","Asian Paints","HUL","Titan","M&M","Power Grid","NTPC","Coal India","ONGC","Tata Motors","Ultratech","Cipla","Dr Reddy","Godrej Consumer"],
"icici pru bluechip":["HDFC Bank","Infosys","Reliance","ICICI Bank","TCS","L&T","Kotak MB","HUL","Axis Bank","ITC","Sun Pharma","Asian Paints","Bajaj Finance","Maruti","Wipro","SBI","HCL Tech","Bharti Airtel","Nestle","NTPC","Titan","M&M","Power Grid","Ultratech","Bajaj Auto","Eicher Motors","Divi Lab","Cipla","Tech Mahindra","Tata Consumer"],
"parag parikh":["HDFC Bank","Infosys","ITC","Axis Bank","HCL Tech","Coal India","Power Grid","Maruti","HUL","ICICI Bank","Microsoft","Alphabet","Amazon","Meta","Berkshire","ONGC","BPCL","Indian Hotels","Persistent","Mphasis","Bajaj Auto","Hero MotoCorp","NMDC","Zydus Life","Dr Reddy","Cipla"],
"kotak emerging":["Persistent","Coforge","KEC Intl","Carborundum","Kajaria","Safari","Affle","Dixon Tech","Techno Elec","Sona BLW","KPIT Tech","CG Power","Blue Star","Polycab","KEI","Lemon Tree","CAMS","Metropolis","Tata Elxsi","Astral","Prince Pipes"],
"axis midcap":["Persistent","Coforge","Mphasis","KPIT Tech","Dixon Tech","Voltas","Cholamandalam","Trent","BSE","Cummins","Supreme Ind","Crompton","Thermax","Kajaria","Astral","Laurus Labs","Eris Life","Ajanta Pharma","Balkrishna Ind"],
"hdfc top 100":["HDFC Bank","Infosys","Reliance","ICICI Bank","TCS","Axis Bank","L&T","Kotak MB","HUL","Bharti Airtel","ITC","SBI","Bajaj Finance","Sun Pharma","Asian Paints","Maruti","HCL Tech","Titan","M&M","NTPC","Power Grid","Ultratech","Wipro","ONGC","Coal India","BPCL","Bajaj Auto","Eicher Motors","Tech Mahindra"],
"nifty 50":["HDFC Bank","Infosys","Reliance","ICICI Bank","TCS","Kotak MB","HUL","Axis Bank","L&T","Bajaj Finance","Bharti Airtel","Asian Paints","Maruti","Titan","HCL Tech","Sun Pharma","ITC","M&M","Ultratech","NTPC","Power Grid","Bajaj Auto","Eicher Motors","Wipro","Tech Mahindra","Divi Lab","SBI Life","HDFC Life","Tata Steel","Adani Enterprises"],
"sbi small cap":["Blue Star","Techno Elec","Finolex","KEI","Lemon Tree","Safari","CAMS","Metropolis","Polycab","Havells","Crompton","Voltas","Navin Fluorine","Fine Org","Vinati","Astral","Prince Pipes","Minda","Radico"],
"hdfc midcap":["Cholamandalam","Persistent","Supreme Ind","Cummins","Voltas","BSE","Trent","KPIT Tech","Dixon Tech","Thermax","Crompton","Coforge","Mphasis","Astral","Laurus Labs","Balkrishna"],
"kotak flexicap":["HDFC Bank","ICICI Bank","Infosys","Reliance","Axis Bank","Bharti Airtel","TCS","L&T","SBI","ITC","Bajaj Finance","Sun Pharma","HCL Tech","Maruti","Asian Paints","HUL","Titan","M&M","Power Grid","NTPC"],
"nippon small cap":["HDFC Bank","SBI","ICICI Bank","Infosys","Reliance","TCS","Tata Motors","Tata Steel","Maruti","Bajaj Finance","HUL","Bharti Airtel","Ultratech","Power Grid","NTPC","Coal India","Titan","Axis Bank"],
"franklin india bluechip":["HDFC Bank","ICICI Bank","Infosys","Reliance","TCS","Kotak MB","L&T","Axis Bank","Sun Pharma","Maruti","HCL Tech","Bharti Airtel","Asian Paints","Bajaj Finance","HUL","Titan","ITC","M&M"],
}

def fund_key(name):
    n=name.lower()
    best,bs=None,0
    for k in FH:
        words=k.split()
        sc=sum(1 for w in words if len(w)>3 and w in n)
        if sc>bs: best,bs=k,sc
    return best if bs>0 else None

# ═══════════ SAFE STOCKS ═══════════
STOCKS={
    "RELIANCE.NS":{"name":"Reliance Industries","sector":"Energy/Conglomerate","safety":"HIGH","cap":"Large"},
    "TCS.NS":{"name":"TCS","sector":"IT","safety":"HIGH","cap":"Large"},
    "HDFCBANK.NS":{"name":"HDFC Bank","sector":"Banking","safety":"HIGH","cap":"Large"},
    "INFY.NS":{"name":"Infosys","sector":"IT","safety":"HIGH","cap":"Large"},
    "ICICIBANK.NS":{"name":"ICICI Bank","sector":"Banking","safety":"HIGH","cap":"Large"},
    "KOTAKBANK.NS":{"name":"Kotak Mahindra Bank","sector":"Banking","safety":"HIGH","cap":"Large"},
    "AXISBANK.NS":{"name":"Axis Bank","sector":"Banking","safety":"HIGH","cap":"Large"},
    "BAJFINANCE.NS":{"name":"Bajaj Finance","sector":"NBFC","safety":"HIGH","cap":"Large"},
    "HINDUNILVR.NS":{"name":"Hindustan Unilever (HUL)","sector":"FMCG","safety":"HIGH","cap":"Large"},
    "ASIANPAINT.NS":{"name":"Asian Paints","sector":"Paints","safety":"HIGH","cap":"Large"},
    "TITAN.NS":{"name":"Titan Company","sector":"Consumer","safety":"HIGH","cap":"Large"},
    "NESTLEIND.NS":{"name":"Nestle India","sector":"FMCG","safety":"HIGH","cap":"Large"},
    "MARUTI.NS":{"name":"Maruti Suzuki","sector":"Auto","safety":"HIGH","cap":"Large"},
    "LT.NS":{"name":"L&T","sector":"Infrastructure","safety":"HIGH","cap":"Large"},
    "HCLTECH.NS":{"name":"HCL Technologies","sector":"IT","safety":"HIGH","cap":"Large"},
    "WIPRO.NS":{"name":"Wipro","sector":"IT","safety":"HIGH","cap":"Large"},
    "BHARTIARTL.NS":{"name":"Bharti Airtel","sector":"Telecom","safety":"HIGH","cap":"Large"},
    "ITC.NS":{"name":"ITC Limited","sector":"FMCG","safety":"HIGH","cap":"Large"},
    "SUNPHARMA.NS":{"name":"Sun Pharmaceutical","sector":"Pharma","safety":"HIGH","cap":"Large"},
    "DRREDDY.NS":{"name":"Dr Reddy's Labs","sector":"Pharma","safety":"HIGH","cap":"Large"},
    "CIPLA.NS":{"name":"Cipla","sector":"Pharma","safety":"HIGH","cap":"Large"},
    "DIVISLAB.NS":{"name":"Divi's Laboratories","sector":"Pharma","safety":"HIGH","cap":"Large"},
    "BAJAJ-AUTO.NS":{"name":"Bajaj Auto","sector":"Auto","safety":"HIGH","cap":"Large"},
    "M&M.NS":{"name":"Mahindra & Mahindra","sector":"Auto","safety":"HIGH","cap":"Large"},
    "EICHERMOT.NS":{"name":"Eicher Motors (Royal Enfield)","sector":"Auto","safety":"HIGH","cap":"Large"},
    "TECHM.NS":{"name":"Tech Mahindra","sector":"IT","safety":"HIGH","cap":"Large"},
    "NTPC.NS":{"name":"NTPC","sector":"Power/PSU","safety":"HIGH","cap":"Large"},
    "POWERGRID.NS":{"name":"Power Grid Corp","sector":"Power/PSU","safety":"HIGH","cap":"Large"},
    "ULTRACEMCO.NS":{"name":"Ultratech Cement","sector":"Cement","safety":"HIGH","cap":"Large"},
    "PIDILITIND.NS":{"name":"Pidilite Industries","sector":"Specialty Chemicals","safety":"HIGH","cap":"Large"},
    "HAVELLS.NS":{"name":"Havells India","sector":"Electricals","safety":"HIGH","cap":"Large"},
    "SBILIFE.NS":{"name":"SBI Life Insurance","sector":"Insurance","safety":"HIGH","cap":"Large"},
    "HDFCLIFE.NS":{"name":"HDFC Life Insurance","sector":"Insurance","safety":"HIGH","cap":"Large"},
    "TATAMOTORS.NS":{"name":"Tata Motors","sector":"Auto","safety":"MEDIUM","cap":"Large"},
    "COALINDIA.NS":{"name":"Coal India","sector":"Mining/PSU","safety":"MEDIUM","cap":"Large"},
    "ONGC.NS":{"name":"ONGC","sector":"Oil/PSU","safety":"MEDIUM","cap":"Large"},
    "PERSISTENT.NS":{"name":"Persistent Systems","sector":"IT","safety":"HIGH","cap":"Mid"},
    "COFORGE.NS":{"name":"Coforge","sector":"IT","safety":"HIGH","cap":"Mid"},
    "MPHASIS.NS":{"name":"Mphasis","sector":"IT","safety":"HIGH","cap":"Mid"},
    "KPITTECH.NS":{"name":"KPIT Technologies","sector":"Auto IT","safety":"HIGH","cap":"Mid"},
    "POLYCAB.NS":{"name":"Polycab India","sector":"Electricals","safety":"HIGH","cap":"Mid"},
    "CHOLAFIN.NS":{"name":"Cholamandalam Finance","sector":"NBFC","safety":"HIGH","cap":"Mid"},
    "TRENT.NS":{"name":"Trent (Westside/Zudio)","sector":"Retail","safety":"HIGH","cap":"Mid"},
    "DMART.NS":{"name":"Avenue Supermarts (DMart)","sector":"Retail","safety":"HIGH","cap":"Mid"},
    "CUMMINSIND.NS":{"name":"Cummins India","sector":"Industrials","safety":"HIGH","cap":"Mid"},
    "ABB.NS":{"name":"ABB India","sector":"Industrials","safety":"HIGH","cap":"Mid"},
    "ASTRAL.NS":{"name":"Astral Limited","sector":"Building Materials","safety":"HIGH","cap":"Mid"},
    "SUPREMEIND.NS":{"name":"Supreme Industries","sector":"Plastics","safety":"HIGH","cap":"Mid"},
    "BSE.NS":{"name":"BSE Limited","sector":"Exchange","safety":"HIGH","cap":"Mid"},
    "CDSL.NS":{"name":"CDSL","sector":"Financial Infrastructure","safety":"HIGH","cap":"Mid"},
    "CAMS.NS":{"name":"CAMS","sector":"Financial Infrastructure","safety":"HIGH","cap":"Mid"},
    "DIXON.NS":{"name":"Dixon Technologies","sector":"Electronics","safety":"MEDIUM","cap":"Mid"},
    "BERGERPAINTS.NS":{"name":"Berger Paints","sector":"Paints","safety":"HIGH","cap":"Mid"},
    "CROMPTON.NS":{"name":"Crompton Greaves Consumer","sector":"Electricals","safety":"HIGH","cap":"Mid"},
    "VOLTAS.NS":{"name":"Voltas","sector":"Consumer Durables","safety":"HIGH","cap":"Mid"},
    "BLUESTARCO.NS":{"name":"Blue Star","sector":"Air Conditioning","safety":"HIGH","cap":"Mid"},
}
AVOID={"SUZLON.NS","YESBANK.NS","RCOM.NS","GTL.NS","SPICEJET.NS","UNITECH.NS","DHFL.NS"}

def search_stocks(q):
    ql=q.lower()
    return [{"symbol":s,"name":i["name"],"sector":i["sector"],"safety":i["safety"],"cap":i["cap"]}
            for s,i in STOCKS.items()
            if ql in i["name"].lower() or ql in s.lower() or ql in i["sector"].lower()][:10]

# ═══════════ XIRR ENGINE ═══════════
def calc_xirr(flows, dates):
    if len(flows)<2: return None
    d0=dates[0]
    t=[(d-d0).days/365.25 for d in dates]
    def npv(r): return sum(cf/(1+r)**ti for cf,ti in zip(flows,t))
    try: return round(brentq(npv,-0.9999,10.0,maxiter=500)*100,2)
    except: return None

# ═══════════ MONTE CARLO ═══════════
def monte_carlo(existing, sip, years, n=10000):
    months=int(years*12)
    if months<=0: return {"prob_2x":0,"prob_1_5x":0,"median":0,"p25":0,"p75":0,"extra_sip":0,"invested":0}
    np.random.seed(42)
    mu,sigma=0.0095,0.038
    rets=np.random.normal(mu,sigma,(n,months))
    port=np.full(n,float(existing))
    for m in range(months): port=port*(1+rets[:,m])+sip
    port.sort()
    inv=int(existing+sip*months)
    t2=inv*2; t15=inv*1.5
    p2=round(float(np.mean(port>=t2))*100,1)
    p15=round(float(np.mean(port>=t15))*100,1)
    med=int(np.median(port))
    p25=int(np.percentile(port,25))
    p75=int(np.percentile(port,75))
    shortfall=max(0,t2-med)
    extra=int(round(shortfall/max(months,1)/500)*500) if shortfall>0 else 0
    return {"prob_2x":p2,"prob_1_5x":p15,"median":med,"p25":p25,"p75":p75,"extra_sip":extra,"invested":inv}

# ═══════════ RISK METRICS ═══════════
def risk_metrics(returns):
    if len(returns)<5: return {}
    r=np.array(returns)
    mean=np.mean(r); std=np.std(r)
    rf=0.068/12
    sharpe=round(float((mean-rf)/std*np.sqrt(12)),3) if std>0 else None
    dn=r[r<0]
    dstd=np.std(dn) if len(dn)>0 else std
    sortino=round(float((mean-rf)/dstd*np.sqrt(12)),3) if dstd>0 else None
    s=np.sort(r)
    tail=s[:max(1,int(len(r)*0.05))]
    cvar=round(float(np.mean(tail))*100,2)
    vol=round(float(std*np.sqrt(12))*100,2)
    return {"sharpe":sharpe,"sortino":sortino,"cvar_95":cvar,"volatility":vol}

# ═══════════ MVO OPTIMIZATION ═══════════
def mvo_optimize(expected_returns, cov_matrix, risk_free=0.068):
    n=len(expected_returns)
    er=np.array(expected_returns)
    cov=np.array(cov_matrix)
    def neg_sharpe(w):
        ret=np.dot(w,er)
        vol=np.sqrt(np.dot(w,np.dot(cov,w)))
        return -(ret-risk_free)/vol if vol>0 else 0
    bounds=[(0.05,0.60)]*n
    constraints=[{"type":"eq","fun":lambda w:np.sum(w)-1}]
    x0=[1/n]*n
    try:
        res=minimize(neg_sharpe,x0,method="SLSQP",bounds=bounds,constraints=constraints,options={"maxiter":1000})
        if res.success: return [round(float(w),4) for w in res.x]
    except: pass
    return [round(1/n,4)]*n

# ═══════════ MODELS ═══════════
class Holding(BaseModel):
    name: str
    asset_class: str = "mutual_fund"  # mutual_fund | stock | etf | fd | gold
    current_value: float
    invested_amount: float
    units: Optional[float] = None
    avg_buy_price: Optional[float] = None
    scheme_code: Optional[str] = None
    ticker: Optional[str] = None
    plan_type: str = "regular"
    purchase_date: str = "2022-01-01"

class Goal(BaseModel):
    name: str = "Wealth Creation"
    target_amount: float = 0
    target_year: int = 2040

class HealthReq(BaseModel):
    holdings: List[Holding]
    goals: List[Goal] = []
    age: int = 30
    monthly_income: float = 0

class ConReq(BaseModel):
    goal: str = "wealth"
    timeline_years: int = 5
    mode: str = "sip"           # "sip" or "lumpsum"
    monthly_sip: float = 10000
    lumpsum_amount: float = 0
    expected_return_pct: float = 12
    risk: str = "medium"        # low | medium | high
    age: int = 30
    monthly_income: float = 80000
    existing_savings: float = 0
    current_month: int = 1      # For SIP: which month reconstruction

class ChatReq(BaseModel):
    message: str
    context: Optional[dict] = None

# ═══════════ HEALTH CHECK ENGINE ═══════════
@app.post("/api/health-check")
async def health_check(req: HealthReq):
    if not req.holdings:
        raise HTTPException(400, "No holdings provided")

    # 1. Fetch live data + compute per-holding metrics
    holdings_out = []
    total_val = 0.0
    total_inv = 0.0
    xirr_num = 0.0
    xirr_den = 0.0
    approx_monthly_rets = []
    live_count = 0

    for h in req.holdings:
        cv = h.current_value
        inv = h.invested_amount or cv
        curr_price = None
        live = False

        try:
            pd_obj = datetime.strptime(h.purchase_date[:10], "%Y-%m-%d").date()
        except:
            pd_obj = date(2022, 1, 1)

        # ── Mutual Fund: fetch real NAV ──
        if h.asset_class in ("mutual_fund", "etf") and h.scheme_code and h.units:
            curr_nav, nav_date = nav_latest(h.scheme_code)
            buy_nav = nav_on_date(h.scheme_code, pd_obj)
            if curr_nav and buy_nav:
                cv = round(h.units * curr_nav, 2)
                inv = round(h.units * buy_nav, 2)
                curr_price = curr_nav
                live = True
                live_count += 1

        # ── Stock: fetch real price ──
        elif h.asset_class == "stock" and h.ticker and h.units:
            price = stock_price(h.ticker)
            if price:
                cv = round(h.units * price, 2)
                if h.avg_buy_price and h.units:
                    inv = round(h.units * h.avg_buy_price, 2)
                curr_price = price
                live = True
                live_count += 1

        total_val += cv
        total_inv += inv
        ret_pct = round((cv - inv) / inv * 100, 2) if inv > 0 else 0
        xi = calc_xirr([-inv, cv], [pd_obj, date.today()])

        if xi is not None:
            xirr_num += xi * cv
            xirr_den += cv

        ter = get_ter(h.name, h.plan_type) if h.asset_class in ("mutual_fund","etf") else 0

        # Screen stocks
        screen = None
        if h.asset_class == "stock":
            sym = h.ticker or ""
            if sym in AVOID:
                screen = {"pass": False, "msg": "On fraud/avoid watchlist"}
            elif sym in STOCKS:
                screen = {"pass": True, "safety": STOCKS[sym]["safety"], "msg": STOCKS[sym]["sector"]}
            else:
                screen = {"pass": None, "msg": "Not in screened database — verify independently"}

        # Approx monthly return for risk metrics
        months = max(1, (date.today() - pd_obj).days // 30)
        m_ret = (1 + ret_pct/100)**(1/months) - 1
        approx_monthly_rets.extend([m_ret] * min(months, 24))

        holdings_out.append({
            "name": h.name, "asset_class": h.asset_class,
            "current_value": cv, "invested": inv,
            "return_pct": ret_pct, "xirr": xi,
            "plan": h.plan_type, "ter": ter,
            "live": live, "curr_price": curr_price,
            "ticker": h.ticker, "scheme_code": h.scheme_code,
            "screen": screen,
        })

    port_xirr = round(xirr_num / xirr_den, 2) if xirr_den > 0 else None
    total_ret = round((total_val - total_inv) / total_inv * 100, 2) if total_inv > 0 else 0

    # 2. Risk metrics
    risk = risk_metrics(approx_monthly_rets) if len(approx_monthly_rets) >= 5 else {}

    # 3. Benchmarks (live)
    nifty_5yr = 14.5  # Fallback
    try:
        h5 = stock_hist("^NSEI", 365*5+30)
        if len(h5) > 200:
            nifty_5yr = round(((h5[-1]["close"]/h5[0]["close"])**(1/5)-1)*100,2)
    except: pass

    benchmarks = {
        "Nifty 50 (5yr CAGR)": {"value": nifty_5yr, "diff": round((port_xirr or 0) - nifty_5yr, 2), "beat": (port_xirr or 0) > nifty_5yr},
        "Nifty 500 (5yr CAGR)": {"value": 15.2, "diff": round((port_xirr or 0) - 15.2, 2), "beat": (port_xirr or 0) > 15.2},
        "Category Average": {"value": 12.8, "diff": round((port_xirr or 0) - 12.8, 2), "beat": (port_xirr or 0) > 12.8},
        "SBI FD (5yr)": {"value": 7.1, "diff": round((port_xirr or 0) - 7.1, 2), "beat": (port_xirr or 0) > 7.1},
    }

    # 4. TER waste
    ter_waste = 0.0
    ter_details = []
    for h_out, h in zip(holdings_out, req.holdings):
        if h.asset_class in ("mutual_fund","etf") and "regular" in h.plan_type.lower():
            dir_ter = get_ter(h.name, "direct")
            waste = round(h_out["current_value"] * (h_out["ter"] - dir_ter) / 100, 2)
            if waste > 0:
                ter_waste += waste
                ter_details.append({
                    "fund": h.name,
                    "regular_ter": h_out["ter"],
                    "direct_ter": dir_ter,
                    "annual_waste_rs": waste,
                    "10yr_loss_rs": int(waste * ((1.12**10-1)/0.12)),
                    "fix": f"Switch to Direct plan on mfcentral.com — same fund, saves ₹{int(waste):,}/year",
                })

    # 5. Fund overlap (Jaccard)
    mf_list = [(h_out, h) for h_out, h in zip(holdings_out, req.holdings) if h.asset_class in ("mutual_fund","etf")]
    overlap_waste = 0.0
    overlap_pairs = []
    for i in range(len(mf_list)):
        for j in range(i+1, len(mf_list)):
            ri, hi = mf_list[i]
            rj, hj = mf_list[j]
            ki = fund_key(hi.name); kj = fund_key(hj.name)
            if not ki or not kj: continue
            si, sj = set(FH[ki]), set(FH[kj])
            inter = si & sj
            jac = len(inter) / len(si | sj)
            if jac >= 0.15:
                waste = round(min(ri["current_value"], rj["current_value"]) * jac * 0.008, 2)
                overlap_waste += waste
                overlap_pairs.append({
                    "fund_a": hi.name, "fund_b": hj.name,
                    "overlap_pct": round(jac*100, 1),
                    "annual_waste_rs": waste,
                    "common_stocks": sorted(inter)[:8],
                    "total_common": len(inter),
                    "fix": f"Replace {hi.name.split('-')[0].strip()} OR {hj.name.split('-')[0].strip()} with a mid-cap or international fund for real diversification",
                })
    overlap_pairs.sort(key=lambda x: x["overlap_pct"], reverse=True)

    # 6. Goals
    goals_out = []
    for g in req.goals:
        yrs = g.target_year - date.today().year
        if yrs <= 0: continue
        mc = monte_carlo(total_val, 0, yrs)
        # Projection using portfolio XIRR or 12% default
        proj_ret = (port_xirr or 12) / 100
        proj_val = int(total_val * (1 + proj_ret)**yrs)
        on_track = proj_val >= g.target_amount * 0.8
        gap = max(0, g.target_amount - proj_val)
        extra_sip_needed = int(round(gap / max(yrs*12,1) / 500)*500) if gap > 0 else 0
        goals_out.append({
            "name": g.name, "target": g.target_amount, "year": g.target_year,
            "years_left": yrs, "projected_value": proj_val,
            "on_track": on_track, "gap": gap,
            "extra_sip_needed": extra_sip_needed,
            "monte_carlo": mc,
            "explanation": (
                f"At your current XIRR of {port_xirr or 12}%/year, ₹{int(total_val):,} grows to "
                f"₹{proj_val:,} by {g.target_year}. "
                + (f"You need ₹{int(g.target_amount):,}. Gap = ₹{gap:,}. "
                   f"Increase SIP by ₹{extra_sip_needed:,}/month to close this gap."
                   if gap > 0 else f"On track ✓ — projected ₹{proj_val:,} exceeds target ₹{int(g.target_amount):,}.")
            ),
        })

    # 7. Score
    score = 100
    if port_xirr is not None:
        if port_xirr < 6: score -= 25
        elif port_xirr < 10: score -= 15
        elif port_xirr < 12: score -= 7
        if port_xirr > 16: score += 3
    ter_pct = ter_waste / total_val * 100 if total_val > 0 else 0
    if ter_pct > 1.2: score -= 22
    elif ter_pct > 0.7: score -= 14
    elif ter_pct > 0.3: score -= 7
    ovlp_pct = overlap_waste / total_val * 100 if total_val > 0 else 0
    if ovlp_pct > 1: score -= 16
    elif ovlp_pct > 0.5: score -= 9
    elif ovlp_pct > 0.1: score -= 4
    sharpe = risk.get("sharpe")
    if sharpe is not None:
        if sharpe < 0: score -= 12
        elif sharpe < 0.5: score -= 6
        elif sharpe > 1.2: score += 4
    for g in goals_out:
        if not g["on_track"]: score -= 8
    score = max(10, min(99, score))

    grades = [("A","Excellent",86),("B","Good",71),("C","Fair — Needs Attention",56),("D","Poor — Act Now",41),("F","Critical — Immediate Action",0)]
    grade, glabel = next(((g,l) for g,l,t in grades if score>=t), ("F","Critical"))

    # 8. Issues (ranked by ₹ impact, with both fund AND stock fixes)
    issues = []

    if ter_waste > 0:
        affected = [d["fund"] for d in ter_details]
        issues.append({
            "rank": 0,
            "title": "Regular Plan Cost Leak",
            "cost_rs": int(ter_waste),
            "cost_10yr_rs": int(ter_waste * ((1.12**10-1)/0.12)),
            "severity": "high",
            "what_is_happening": f"You have {len(ter_details)} mutual fund(s) in Regular plan. Regular and Direct are 100% identical funds — same manager, same stocks, same performance. But Regular charges {ter_details[0].get('regular_ter',1.5)}% TER vs Direct's {ter_details[0].get('direct_ter',0.5)}% TER. That {round(ter_details[0].get('regular_ter',1.5)-ter_details[0].get('direct_ter',0.5),2)}% difference goes to your distributor, not to you.",
            "rupee_impact": f"You are losing ₹{int(ter_waste):,} every year. Over 10 years at 12% CAGR, this compounds to ₹{int(ter_waste*((1.12**10-1)/0.12)):,} permanently lost.",
            "exact_fix": [f"Switch '{d['fund'][:40]}' to Direct plan on mfcentral.com. Saves ₹{int(d['annual_waste_rs']):,}/year." for d in ter_details],
            "is_free": True,
        })

    if overlap_pairs:
        w = overlap_pairs[0]
        issues.append({
            "rank": 0,
            "title": "Fund Overlap — Paying Double",
            "cost_rs": int(overlap_waste),
            "cost_10yr_rs": int(overlap_waste * ((1.12**10-1)/0.12)),
            "severity": "high",
            "what_is_happening": f"Your worst overlap: {w['fund_a'][:35]} AND {w['fund_b'][:35]} share {w['overlap_pct']}% of the same stocks ({w['total_common']} common stocks including {', '.join(w['common_stocks'][:4])}). You are paying TER on both funds for holding the same stocks twice.",
            "rupee_impact": f"This overlap is costing you ₹{int(overlap_waste):,}/year in duplicate TER charges.",
            "exact_fix": [w["fix"]],
            "alternatives": {
                "mutual_fund": "Replace with: Axis Midcap Fund Direct, Kotak Emerging Equity Direct, or Motilal Oswal Nasdaq 100 FOF Direct",
                "stock": "Or replace with individual quality stocks: HDFC Bank (Banking), Asian Paints (Consumer), Persistent Systems (IT Mid-cap)",
            },
            "is_free": len(issues) == 0,
        })

    if port_xirr is not None and port_xirr < 11:
        beats = sum(1 for b in benchmarks.values() if b["beat"])
        issues.append({
            "rank": 0,
            "title": "Your Returns Are Below Market",
            "cost_rs": int(total_val * 0.025),
            "cost_10yr_rs": int(total_val * 0.025 * ((1.12**10-1)/0.12)),
            "severity": "medium",
            "what_is_happening": f"Your portfolio XIRR is {port_xirr}%/year. You are beating only {beats}/4 benchmarks. A simple Nifty 50 Index Fund has given ~{nifty_5yr}%/year with just 0.10% TER — no stock picking needed.",
            "rupee_impact": f"Underperformance vs Nifty 50 is costing you approximately ₹{int(total_val*0.025):,}/year in missed gains.",
            "exact_fix": [
                "Replace underperforming active funds with HDFC Nifty 50 Index Fund Direct (TER 0.10%) as core holding",
                "Or add quality individual stocks: TCS (IT, 10yr CAGR 18%), Asian Paints (Consumer, 10yr CAGR 22%), Bajaj Finance (NBFC, 10yr CAGR 30%)",
            ],
            "is_free": len(issues) == 0,
        })

    if sharpe is not None and sharpe < 0.5:
        issues.append({
            "rank": 0,
            "title": "High Risk, Low Reward",
            "cost_rs": int(total_val * 0.015),
            "cost_10yr_rs": int(total_val * 0.015 * ((1.12**10-1)/0.12)),
            "severity": "medium",
            "what_is_happening": f"Sharpe Ratio = {sharpe}. This means for every 1 unit of risk you take, you earn only {sharpe} units of return above FD rate. A well-run portfolio should have Sharpe > 1.0. CVaR = {risk.get('cvar_95','N/A')}% — in bad months you lose this much on average.",
            "rupee_impact": f"Poor risk-adjusted returns are effectively costing ₹{int(total_val*0.015):,}/year compared to a better-constructed portfolio.",
            "exact_fix": [
                "Shift 15-20% from volatile small/mid cap to HDFC Bank or Infosys (stable large cap)",
                "Add HDFC Short Duration Fund Direct for debt buffer — reduces volatility without hurting returns significantly",
            ],
            "is_free": len(issues) == 0,
        })

    for g in goals_out:
        if not g["on_track"]:
            issues.append({
                "rank": 0,
                "title": f"Goal At Risk: {g['name']}",
                "cost_rs": g["extra_sip_needed"] * 12,
                "cost_10yr_rs": g["extra_sip_needed"] * 12 * 10,
                "severity": "high",
                "what_is_happening": g["explanation"],
                "rupee_impact": f"You need ₹{g['extra_sip_needed']:,}/month more SIP to reach ₹{int(g['target']):,} by {g['year']}.",
                "exact_fix": [
                    f"Increase monthly SIP by ₹{g['extra_sip_needed']:,}",
                    f"Or extend timeline by {2} years and keep current SIP",
                    "Or shift to higher equity allocation if risk tolerance allows",
                ],
                "is_free": len(issues) == 0,
            })

    issues.sort(key=lambda x: x["cost_rs"], reverse=True)
    for i, iss in enumerate(issues):
        iss["rank"] = i + 1
        if i > 0: iss["is_free"] = False

    # Summary in plain English
    summary = (
        f"Your portfolio is worth ₹{int(total_val):,} today (you invested ₹{int(total_inv):,}). "
        f"Total return: {total_ret}%"
        + (f", XIRR: {port_xirr}% per year." if port_xirr else ".")
    )
    if issues:
        top = issues[0]
        summary += (
            f"\n\nBiggest problem: {top['title']}. "
            f"This is costing you ₹{top['cost_rs']:,} every year. "
            f"Over 10 years that compounds to ₹{top['cost_10yr_rs']:,} permanently lost."
            f"\n\nFix: {top['exact_fix'][0] if top['exact_fix'] else 'See details below.'}"
        )
        total_saveable = int(ter_waste + overlap_waste)
        if total_saveable > 0:
            summary += f"\n\nIf you fix TER waste + overlap today: you save ₹{total_saveable:,}/year = ₹{int(total_saveable*((1.12**10-1)/0.12)):,} over 10 years."

    return {
        "score": score, "grade": grade, "label": glabel,
        "total_value_rs": int(total_val), "total_invested_rs": int(total_inv),
        "total_return_pct": total_ret, "portfolio_xirr_pct": port_xirr,
        "ter_waste_rs": int(ter_waste), "overlap_waste_rs": int(overlap_waste),
        "total_saveable_rs": int(ter_waste + overlap_waste),
        "risk_metrics": risk, "benchmarks": benchmarks,
        "issues": issues[:5],
        "holdings": holdings_out, "goals": goals_out,
        "summary_plain_english": summary,
        "data_note": f"Live data: {live_count}/{len(holdings_out)} holdings",
        "ter_details": ter_details, "overlap_pairs": overlap_pairs,
    }

# ═══════════ CONSTRUCTION ENGINE ═══════════

# Market context June 2026
MARKET = {
    "nifty_pe": 22.1,
    "midcap_pe": 34.5,
    "smallcap_pe": 38.2,
    "rbi_rate": 6.25,
    "rate_trend": "CUTTING",
    "gold_1yr": 22.5,
    "usd_inr": 84.2,
}

# Safe recommended stocks per risk level
STOCKS_BY_RISK = {
    "low": [
        {"sym":"HDFCBANK.NS","name":"HDFC Bank","why":"Most stable bank in India. 15yr CAGR 17%. Consistent ROE 16%+. Zero fraud history.","pct":8},
        {"sym":"INFY.NS","name":"Infosys","why":"IT giant. High dividend yield. Strong cash flow. 10yr CAGR 18%.","pct":7},
    ],
    "medium": [
        {"sym":"HDFCBANK.NS","name":"HDFC Bank","why":"Core banking holding. Stable, high quality. 15yr CAGR 17%.","pct":6},
        {"sym":"INFY.NS","name":"Infosys","why":"IT leader. High ROE, strong cash flows.","pct":5},
        {"sym":"ASIANPAINT.NS","name":"Asian Paints","why":"Consumer monopoly. 20yr CAGR 22%. No debt.","pct":4},
        {"sym":"PERSISTENT.NS","name":"Persistent Systems","why":"IT mid-cap. 3yr CAGR 50%+. Zero debt. HIGH safety.","pct":5},
    ],
    "high": [
        {"sym":"RELIANCE.NS","name":"Reliance Industries","why":"Conglomerate. Telecom+Retail+Energy. 10yr CAGR 18%.","pct":5},
        {"sym":"HDFCBANK.NS","name":"HDFC Bank","why":"Core banking. Stable foundation.","pct":4},
        {"sym":"ASIANPAINT.NS","name":"Asian Paints","why":"Consumer monopoly. Long-term compounder.","pct":4},
        {"sym":"PERSISTENT.NS","name":"Persistent Systems","why":"High-growth IT mid-cap. Zero debt.","pct":5},
        {"sym":"TITAN.NS","name":"Titan Company","why":"Consumer brand. Watches+Jewellery. 10yr CAGR 25%.","pct":4},
        {"sym":"CUMMINSIND.NS","name":"Cummins India","why":"Industrials leader. Zero debt. 10yr CAGR 20%+.","pct":3},
    ],
}

# MF allocations per risk × timeline (market-adjusted June 2026)
MF_ALLOC = {
    ("low","short"):[ # <3yr
        ("HDFC Short Duration Fund Direct",35,"RBI cutting rates = short duration bonds gain. 7-8%/yr. Low risk."),
        ("Nippon India Liquid Fund Direct",30,"Capital protection. Instant redemption. 6-7%/yr."),
        ("Nippon India Gold Savings Fund Direct",20,"Inflation hedge. Gold +22% in 1yr — maintain as insurance."),
        ("HDFC Nifty 50 Index Fund Direct",15,"Minimum equity. P/E 22 is cheapest in equity universe."),
    ],
    ("low","medium"):[ # 3-7yr
        ("HDFC Nifty 50 Index Fund Direct",35,"Core equity. P/E 22 — best risk-reward in equities right now. 0.10% TER."),
        ("HDFC Short Duration Fund Direct",28,"Rate cutting tailwind. 7-8%/yr. Stability buffer."),
        ("Parag Parikh Flexi Cap Direct",17,"Dynamic + international exposure. Consistent 5yr CAGR 22%+."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",10,"USD diversification. Global AI/tech exposure."),
        ("Nippon India Gold Savings Fund Direct",10,"Macro hedge. Keep fixed — don't increase after +22% run."),
    ],
    ("low","long"):[ # 7yr+
        ("HDFC Nifty 50 Index Fund Direct",38,"Core. 13-15% 10yr CAGR. 0.10% TER. Lowest cost equity exposure."),
        ("Parag Parikh Flexi Cap Direct",18,"Active management + global stocks. Best all-weather fund."),
        ("HDFC Short Duration Fund Direct",22,"Stability. Rate cutting adds 0.5-1% extra return."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",14,"Long-term USD compounding. AI/tech tailwind."),
        ("Nippon India Gold Savings Fund Direct",8,"Insurance. Keep small and fixed."),
    ],
    ("medium","short"):[ # <3yr
        ("HDFC Nifty 50 Index Fund Direct",32,"Large cap equity. P/E 22 — cheapest in equities."),
        ("Mirae Asset Large Cap Fund Direct",10,"Quality active large cap."),
        ("HDFC Short Duration Fund Direct",33,"Rate cutting cycle. Core debt for 1-3yr."),
        ("Nippon India Gold Savings Fund Direct",12,"Volatility hedge."),
        ("Nippon India Liquid Fund Direct",13,"Liquidity buffer."),
    ],
    ("medium","medium"):[ # 3-7yr
        ("HDFC Nifty 50 Index Fund Direct",32,"OVERWEIGHT vs midcap. P/E 22 vs midcap P/E 34 = clear winner."),
        ("Parag Parikh Flexi Cap Direct",20,"Dynamic allocation + FAANG global stocks."),
        ("HDFC Short Duration Fund Direct",20,"Stability + rate cutting benefit."),
        ("Kotak Emerging Equity Fund Direct",10,"Mid cap. P/E 34 expensive — limited allocation for 5yr+ horizon."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",10,"Global diversification."),
        ("ICICI Pru Bluechip Fund Direct",8,"Quality active large cap."),
    ],
    ("medium","long"):[ # 7yr+
        ("HDFC Nifty 50 Index Fund Direct",24,"Core index. 10yr horizon absorbs current P/E 22 easily."),
        ("Kotak Emerging Equity Fund Direct",14,"Mid cap. P/E 34 expensive but fine for 10yr SIP."),
        ("Parag Parikh Flexi Cap Direct",18,"Dynamic + global. Best all-around fund."),
        ("HDFC Short Duration Fund Direct",12,"Stability buffer."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",12,"USD compounding."),
        ("Nippon India Gold Savings Fund Direct",5,"Insurance only."),
    ],
    ("high","short"):[ # <5yr
        ("HDFC Nifty 50 Index Fund Direct",42,"Max equity but safest. P/E 22 vs midcap 34."),
        ("Mirae Asset Emerging Bluechip Direct",15,"Large+mid blend. Reduced — midcap expensive."),
        ("HDFC Short Duration Fund Direct",22,"Risk buffer."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",21,"USD diversification."),
    ],
    ("high","medium"):[ # 5-10yr
        ("HDFC Nifty 50 Index Fund Direct",20,"Core equity. P/E 22 best value."),
        ("Kotak Emerging Equity Fund Direct",18,"Mid cap. SIP will average well on any correction."),
        ("Parag Parikh Flexi Cap Direct",15,"Alpha + global."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",15,"USD/global tech."),
        ("Nippon India Gold Savings Fund Direct",5,"Small hedge."),
    ],
    ("high","long"):[ # 10yr+
        ("HDFC Nifty 50 Index Fund Direct",18,"Core index. 10yr+ absorbs all valuations."),
        ("Kotak Emerging Equity Fund Direct",18,"Mid cap growth."),
        ("Nippon India Small Cap Fund Direct",8,"REDUCED from 15% — P/E 38 expensive. Only for 10yr+ conviction."),
        ("Parag Parikh Flexi Cap Direct",12,"Dynamic alpha + global."),
        ("Motilal Oswal Nasdaq 100 FOF Direct",15,"Global AI/tech long-term."),
        ("Nippon India Gold Savings Fund Direct",4,"Insurance only."),
    ],
}

EXPECTED_RETURNS = {
    ("low","short"):8.5, ("low","medium"):9.5, ("low","long"):10.0,
    ("medium","short"):10.5, ("medium","medium"):11.8, ("medium","long"):12.5,
    ("high","short"):12.5, ("high","medium"):14.0, ("high","long"):15.5,
}
RISK_STATS = {
    "low":{"vol":7.5,"sharpe":0.58},
    "medium":{"vol":13.2,"sharpe":0.79},
    "high":{"vol":19.5,"sharpe":0.89},
}
BACKTEST = {
    "low":{"2008":-8,"2020":-5,"2022":-3,"10yr_avg":9.0},
    "medium":{"2008":-22,"2020":-18,"2022":-10,"10yr_avg":11.5},
    "high":{"2008":-38,"2020":-31,"2022":-17,"10yr_avg":13.8},
}

MAX_REALISTIC_RETURN = {1:7, 2:8, 3:9, 5:11, 7:13, 10:14.5, 15:15, 30:15.5}

def get_max_realistic(years):
    for y in sorted(MAX_REALISTIC_RETURN.keys(), reverse=True):
        if years >= y: return MAX_REALISTIC_RETURN[y]
    return 8

@app.post("/api/construct")
async def construct(req: ConReq):
    risk = req.risk if req.risk in ("low","medium","high") else "medium"
    years = req.timeline_years
    max_ret = get_max_realistic(years)
    unrealistic = req.expected_return_pct > max_ret + 2

    hkey = "short" if years <= 3 else "medium" if years <= 7 else "long"
    # high risk short = use short only if < 5
    if risk == "high": hkey = "short" if years < 5 else "medium" if years <= 10 else "long"

    mf_allocs = MF_ALLOC.get((risk, hkey), MF_ALLOC[("medium","long")])
    stk_allocs = STOCKS_BY_RISK[risk]
    exp_ret = EXPECTED_RETURNS[(risk, hkey)]
    stats = RISK_STATS[risk]
    bt = BACKTEST[risk]

    # Split allocation: MFs get 75-85%, Stocks get 15-25%
    stk_total_pct = sum(s["pct"] for s in stk_allocs)
    mf_total_pct = sum(a[1] for a in mf_allocs)
    # Normalize
    mf_budget = 100 - stk_total_pct
    mf_budget = max(60, min(90, mf_budget))
    stk_budget = 100 - mf_budget

    instruments = []
    monthly = req.monthly_sip if req.mode == "sip" else 0
    total_invest = req.lumpsum_amount if req.mode == "lumpsum" else 0

    for name, raw_pct, reason in mf_allocs:
        pct = round(raw_pct * mf_budget / mf_total_pct)
        if req.mode == "sip":
            amount = max(500, round(pct * monthly / 100 / 500) * 500)
        else:
            amount = round(pct * total_invest / 100 / 100) * 100
        instruments.append({
            "type": "mutual_fund",
            "name": name,
            "allocation_pct": pct,
            "monthly_amount_rs": amount if req.mode == "sip" else None,
            "lumpsum_amount_rs": amount if req.mode == "lumpsum" else None,
            "reason": reason,
            "screen": "AMFI-regulated. Screened.",
        })

    for stk in stk_allocs:
        pct = round(stk["pct"] * stk_budget / stk_total_pct)
        if req.mode == "sip":
            amount = max(0, round(pct * monthly / 100 / 100) * 100)
        else:
            amount = round(pct * total_invest / 100 / 100) * 100
        # Get live price
        price = stock_price(stk["sym"])
        qty = round(amount / price, 2) if price and amount > 0 else None
        instruments.append({
            "type": "stock",
            "name": stk["name"],
            "symbol": stk["sym"],
            "allocation_pct": pct,
            "monthly_amount_rs": amount if req.mode == "sip" else None,
            "lumpsum_amount_rs": amount if req.mode == "lumpsum" else None,
            "current_price_rs": price,
            "approx_qty": qty,
            "reason": stk["why"],
            "screen": STOCKS.get(stk["sym"],{}).get("safety","HIGH"),
        })

    # Normalize to 100%
    tot_pct = sum(ins["allocation_pct"] for ins in instruments)
    if tot_pct != 100 and tot_pct > 0:
        diff = 100 - tot_pct
        instruments[0]["allocation_pct"] += diff

    # Projections
    months = years * 12
    mr = exp_ret / 100 / 12
    if req.mode == "sip":
        fv = monthly * ((1+mr)**months - 1)/mr * (1+mr) + req.existing_savings * (1+exp_ret/100)**years
        total_inv = req.existing_savings + monthly * months
    else:
        fv = total_invest * (1 + exp_ret/100)**years + req.existing_savings * (1+exp_ret/100)**years
        total_inv = total_invest + req.existing_savings

    mc = monte_carlo(req.existing_savings, monthly if req.mode=="sip" else 0, years)

    # Plain English explanation
    mode_str = f"₹{int(monthly):,}/month SIP" if req.mode == "sip" else f"₹{int(total_invest):,} lump sum"
    exp_str = (
        f"\n\n⚠️ IMPORTANT: You expected {req.expected_return_pct}%/year. "
        f"For a {years}-year timeline, the historical maximum for similar portfolios is ~{max_ret}%. "
        f"25%+ returns consistently in public markets = not possible. That is scam territory or extremely concentrated risk. "
        f"This portfolio targets a realistic {exp_ret}%/year."
        if unrealistic else ""
    )

    explanation = (
        f"This {risk.capitalize()} portfolio is built for your {years}-year horizon with {mode_str}.{exp_str}\n\n"
        f"Expected return: {exp_ret}%/year. Sharpe ratio: {stats['sharpe']} (good = >1.0). "
        f"In worst case crashes: 2008 = {bt['2008']}%, 2020 COVID = {bt['2020']}%, 2022 rate hike = {bt['2022']}%.\n\n"
        f"June 2026 Market Applied: Nifty P/E 22 → large cap overweighted vs expensive midcap P/E 34. "
        f"RBI cutting rates → short duration debt overweighted. Gold +22% already → held as small hedge only.\n\n"
        f"Stocks included ({len(stk_allocs)}): "
        + ", ".join(f"{s['name']} ({s['sym'].replace('.NS','')})" for s in stk_allocs)
        + ". All screened: 10yr+ profit consistency, no fraud history, no manipulated price patterns.\n\n"
        f"Projected value in {years} years: ₹{int(fv):,} from ₹{int(total_inv):,} invested. "
        f"Gain: ₹{int(fv-total_inv):,}.\n\n"
        f"Note: These are mathematical projections based on historical return distribution. "
        f"Markets deviate. Your most important action: follow the plan consistently. "
        f"SIP investors benefit from market falls — you buy more units when prices are low."
    )

    # SIP mode: monthly redesign message
    sip_note = None
    if req.mode == "sip":
        sip_note = (
            f"SIP Month {req.current_month}: Allocations shown above are for this month's ₹{int(monthly):,} SIP. "
            f"Every month, prices change, so the quantity of each stock you can buy changes. "
            f"Come back next month — re-run construction with month={req.current_month+1} and we will recalculate "
            f"exact quantities based on that month's prices to keep you on target."
        )

    return {
        "mode": req.mode,
        "risk": risk,
        "timeline_years": years,
        "expected_return_pct": exp_ret,
        "user_expected_pct": req.expected_return_pct,
        "unrealistic_expectation": unrealistic,
        "max_realistic_for_timeline": max_ret,
        "volatility_pct": stats["vol"],
        "sharpe_ratio": stats["sharpe"],
        "projected_value_rs": int(fv),
        "total_invested_rs": int(total_inv),
        "projected_gain_rs": int(fv - total_inv),
        "instruments": instruments,
        "backtest": bt,
        "monte_carlo": mc,
        "market_context": MARKET,
        "explanation_plain_english": explanation,
        "sip_monthly_note": sip_note,
        "disclaimer": "Every instrument requires your explicit approval before any action. Nxance recommends — you decide.",
    }

# ═══════════ NXANCELM CHAT ═══════════
@app.post("/api/chat")
async def chat(req: ChatReq):
    msg = req.message.lower()
    ctx = req.context or {}
    ctype = ctx.get("type","")

    # Knowledge base
    KB = {
        "xirr": "XIRR is the annualised return of your portfolio, accounting for the exact timing and amount of every SIP and lump sum. Unlike simple return %, XIRR correctly values a 30% gain over 5 years as 5.4%/year. It uses the Newton-Raphson algorithm — same as Excel XIRR. It is the most accurate measure of real investment performance.",
        "ter": "TER (Total Expense Ratio) is the annual fee charged by a mutual fund. Regular plan = 1.2-1.8%, Direct plan = 0.1-0.7% — for the IDENTICAL fund. Same stocks, same manager, same performance. The difference goes to your distributor. On ₹5,00,000 invested at 1% extra TER = ₹5,000 lost every year silently.",
        "overlap": "Fund overlap means two funds own the same underlying stocks. If two large-cap funds both hold HDFC Bank, Infosys, Reliance — you pay TER twice for the same exposure. Jaccard score = common stocks ÷ total unique stocks. Above 40% overlap = significant waste.",
        "sharpe": "Sharpe Ratio = (Your Return − Risk Free Rate) ÷ Volatility. Risk-free rate = SBI FD at 6.8%/year. Above 1.0 = excellent risk-adjusted return. 0.5-1.0 = acceptable. Below 0.5 = taking too much risk for the return you are getting.",
        "cvar": "CVaR (Conditional Value at Risk) at 95% = In the worst 5% of months, what is your average loss? If CVaR is -4%, it means in bad market months you lose 4% on average. More honest than max drawdown. Used by all serious institutional investors.",
        "monte carlo": "Monte Carlo simulation runs 10,000 random future market scenarios using historical return patterns. It tells you the probability — for example 72% chance your portfolio reaches ₹50 lakh by 2040. More honest than a single projected number because markets are random.",
        "regular": "Regular vs Direct mutual fund: IDENTICAL portfolio, IDENTICAL fund manager, IDENTICAL stocks. Regular plan pays about 1% commission to your distributor every year. Direct does not. On ₹10 lakh at 12% CAGR for 20 years: Regular = ₹82 lakh. Direct = ₹96 lakh. That ₹14 lakh difference is your distributor's income, not your wealth.",
        "sip": "SIP works through rupee-cost averaging. ₹10,000 buys more units when markets fall and fewer when they rise. Over 10+ years, this automatically reduces your average purchase cost. The best time to continue SIP is when markets are falling — you are buying at a discount.",
        "nifty": "Nifty 50 is India's benchmark of the 50 largest NSE companies. Historical 20-year CAGR is approximately 14.5% per year. If your portfolio XIRR is below Nifty 50, you would have done better with a simple Nifty 50 Index Fund at 0.10% TER — no fund manager needed.",
        "fraud": "Warning signs in stocks: (1) Price moves up sharply without any news — operator/circle trading. (2) Volume spikes without news. (3) Promoter pledge above 50% — dangerous, owner is using stock as debt collateral. (4) Qualified audit reports — auditors found problems. (5) 3+ years of losses with no improvement. (6) Debt-to-equity ratio above 3 for non-banking companies.",
        "ltcg": "LTCG (Long Term Capital Gains) on equity MF and stocks: 12.5% tax on gains above ₹1.25 lakh per year if held more than 1 year. STCG: 20% if held less than 1 year. Debt MF: taxed as per your income tax slab. Plan your redemptions to stay within ₹1.25 lakh LTCG per year to pay zero tax.",
        "lumpsum": "Lumpsum investing vs SIP: Lumpsum is better when markets are low (valuations cheap). SIP is better when markets are uncertain or expensive. Current market: Nifty P/E 22 (slightly above historical average of 20), midcap P/E 34 (expensive). Verdict: SIP is safer right now than full lumpsum in equity.",
        "rebalancing": "Portfolio rebalancing: If equity rallies and becomes 70% of your portfolio (target was 60%), sell equity and buy debt to restore 60:40. This mechanically enforces buy-low, sell-high. Trigger: when any asset class drifts more than 5% from target.",
    }

    for kw, ans in KB.items():
        if kw in msg:
            # Add portfolio context if available
            if ctype == "health_check":
                if kw == "xirr" and ctx.get("portfolio_xirr_pct"):
                    return {"reply": ans + f"\n\nYour portfolio XIRR: {ctx['portfolio_xirr_pct']}% per year."}
                if kw == "ter" and ctx.get("ter_waste_rs"):
                    return {"reply": ans + f"\n\nYour portfolio: TER waste = ₹{ctx['ter_waste_rs']:,} every year. Switching all Regular plans to Direct saves this permanently."}
                if kw == "overlap" and ctx.get("overlap_waste_rs"):
                    return {"reply": ans + f"\n\nYour portfolio: Overlap waste = ₹{ctx['overlap_waste_rs']:,} every year."}
            return {"reply": ans}

    if ctype == "health_check":
        score = ctx.get("score",0)
        grade = ctx.get("grade","")
        xirr = ctx.get("portfolio_xirr_pct")
        tv = ctx.get("total_value_rs",0)
        ti = ctx.get("total_invested_rs",0)
        tr = ctx.get("total_return_pct",0)
        ter_w = ctx.get("ter_waste_rs",0)
        olp_w = ctx.get("overlap_waste_rs",0)
        issues = ctx.get("issues",[])
        bench = ctx.get("benchmarks",{})
        risk = ctx.get("risk_metrics",{})

        if any(w in msg for w in ["score","result","health","explain","summary","tell","how","kaisa"]):
            r = f"Your portfolio scored {score}/100 — Grade {grade}.\n\n"
            r += f"You invested ₹{ti:,} and it is now worth ₹{tv:,}. That is a {tr}% total return"
            if xirr: r += f", which is {xirr}% per year (XIRR)"
            r += ".\n\n"
            if issues:
                top = issues[0]
                r += f"Biggest problem: {top['title']}.\n{top.get('what_is_happening','')}\n\nCost: ₹{top['cost_rs']:,}/year. Over 10 years: ₹{top['cost_10yr_rs']:,} lost.\n\nFix: {top['exact_fix'][0] if top.get('exact_fix') else 'See details.'}"
            total_save = ter_w + olp_w
            if total_save > 0:
                r += f"\n\nIf you fix TER waste and overlap today: ₹{total_save:,}/year saved = ₹{int(total_save*((1.12**10-1)/0.12)):,} over 10 years."
            return {"reply": r}

        if any(w in msg for w in ["issue","problem","fix","improve","wrong","kya galat"]):
            if issues:
                top = issues[0]
                r = f"{top['title']}\n\n{top.get('what_is_happening','')}\n\n"
                r += f"Annual cost: ₹{top['cost_rs']:,}. 10-year cost: ₹{top['cost_10yr_rs']:,}.\n\n"
                if top.get("exact_fix"):
                    r += "How to fix:\n" + "\n".join(f"• {f}" for f in top["exact_fix"])
                if top.get("alternatives"):
                    alt = top["alternatives"]
                    r += f"\n\nAlternatives:\nMutual Fund: {alt.get('mutual_fund','')}\nStocks: {alt.get('stock','')}"
                return {"reply": r}
            return {"reply": "No major issues found in your portfolio. It looks healthy!"}

        if any(w in msg for w in ["benchmark","nifty","compare","beating","performance"]):
            if bench:
                beats = sum(1 for b in bench.values() if b.get("beat"))
                r = f"Your XIRR of {xirr}%/year vs benchmarks:\n\n"
                for n, b in bench.items():
                    sign = "✓ ABOVE" if b.get("beat") else "✗ BELOW"
                    r += f"{sign} {n}: {b['value']}% — you are {abs(b['diff'])}% {'above' if b.get('beat') else 'below'}\n"
                r += f"\nBeating {beats}/{len(bench)} benchmarks."
                return {"reply": r}

        if any(w in msg for w in ["risk","sharpe","cvar","volatility"]):
            if risk:
                r = f"Your portfolio risk metrics:\n\n"
                r += f"• Sharpe Ratio: {risk.get('sharpe','N/A')} — measures return per unit of risk (target: above 1.0)\n"
                r += f"• CVaR 95%: {risk.get('cvar_95','N/A')}% — in your worst months, you lose this much on average\n"
                r += f"• Annual Volatility: {risk.get('volatility','N/A')}%\n"
                r += f"• Sortino Ratio: {risk.get('sortino','N/A')} — penalises only downside risk\n\n"
                if risk.get("sharpe") and risk["sharpe"] < 0.5:
                    r += "Your Sharpe is low — you are taking high risk without getting enough return for it. Consider shifting some allocation to quality large-cap stocks or short-duration debt."
                else:
                    r += "Your risk metrics are within acceptable range."
                return {"reply": r}

        if any(w in msg for w in ["save","saving","how much","loss","waste"]):
            total = ter_w + olp_w
            r = f"Avoidable losses in your portfolio:\n\n"
            if ter_w > 0: r += f"• TER waste (Regular plans): ₹{ter_w:,}/year\n"
            if olp_w > 0: r += f"• Fund overlap waste: ₹{olp_w:,}/year\n"
            r += f"\nTotal: ₹{total:,}/year.\nOver 10 years at 12% CAGR, this compounds to ₹{int(total*((1.12**10-1)/0.12)):,} permanently lost."
            return {"reply": r}

    if ctype == "construction":
        exp = ctx.get("explanation_plain_english","")
        instruments = ctx.get("instruments",[])
        mc = ctx.get("monte_carlo",{})
        proj = ctx.get("projected_value_rs",0)
        years = ctx.get("timeline_years",0)
        mode = ctx.get("mode","sip")

        if any(w in msg for w in ["explain","portfolio","why","result","allocation","tell"]):
            return {"reply": exp or "Run construction first for detailed explanation."}

        if any(w in msg for w in ["stock","which stock","why stock","why these"]):
            stks = [i for i in instruments if i["type"] == "stock"]
            if stks:
                r = f"Stocks selected ({len(stks)}):\n\n"
                for s in stks:
                    r += f"• {s['name']} ({s.get('symbol','')}):\n  Why: {s['reason']}\n"
                    if s.get("current_price_rs"): r += f"  Current price: ₹{s['current_price_rs']:,}\n"
                    if s.get("approx_qty"): r += f"  Approx quantity for this allocation: {s['approx_qty']} shares\n"
                r += "\nAll stocks screened: 10yr+ profit consistency, no fraud/manipulation history, no promoter pledge issues."
                return {"reply": r}
            return {"reply": "No individual stocks in your portfolio. Allocation is in mutual funds only."}

        if any(w in msg for w in ["monte carlo","probability","goal","chance","reach","achieve"]):
            p = mc.get("prob_2x",0)
            med = mc.get("median",0)
            extra = mc.get("extra_sip",0)
            r = f"Monte Carlo simulation (10,000 paths):\n\n"
            r += f"Probability of 2× your invested amount: {p}%\n"
            r += f"Median outcome in {years} years: ₹{med:,}\n"
            r += f"Projected value: ₹{proj:,}\n\n"
            r += f"{p}% chance means if this scenario plays out 100 times, you reach 2× in {p} out of 100 cases.\n\n"
            if extra > 0: r += f"To improve above 70% probability: increase {mode} amount by ₹{extra:,}/month."
            else: r += "You are on track to meet your goal with current investment."
            return {"reply": r}

        if any(w in msg for w in ["sip","monthly","redesign","next month","change"]):
            note = ctx.get("sip_monthly_note","")
            return {"reply": note or "SIP redesign: Come back each month — prices will have changed. Re-run construction and we will recalculate exact quantities to keep you on track."}

        if any(w in msg for w in ["realistic","return","25","expect","possible"]):
            unreal = ctx.get("unrealistic_expectation",False)
            ur = ctx.get("user_expected_pct",0)
            mr = ctx.get("max_realistic_for_timeline",0)
            er = ctx.get("expected_return_pct",0)
            if unreal:
                return {"reply": f"Your expected return of {ur}%/year is not realistic for a {years}-year horizon.\n\nHistorical Nifty 50 CAGR: 14.5%/year over 20 years. Best performing Indian equity fund: ~20% over 10yr. Consistent 25%+: impossible in public markets — that is speculation or fraud territory.\n\nMaximum realistic for {years}-year timeline: ~{mr}%/year.\nThis portfolio is built for {er}%/year, which is achievable with discipline."}
            return {"reply": f"Yes, {ur}%/year is realistic for your {years}-year horizon. This portfolio targets {er}%/year based on historical return patterns for this allocation."}

    if any(w in msg for w in ["hi","hello","namaste","hey","start"]):
        return {"reply": "Hello! I'm NxanceLM.\n\nRun a Health Check or Construction first — then ask me anything about your specific portfolio results.\n\nI answer with your actual numbers, not generic advice."}

    return {"reply": f"I understood: '{req.message}'\n\nFor best answers, run a Health Check or Construction first — I will use your actual portfolio data to answer.\n\nI can explain: XIRR, TER, overlap, Sharpe, CVaR, Monte Carlo, Regular vs Direct, SIP, lumpsum, stocks, return expectations, portfolio rebalancing, LTCG tax."}

# ═══════════ SEARCH APIs ═══════════
@app.get("/api/search/mf")
async def api_search_mf(q: str):
    results = amfi_search(q)
    return {"results": [{"code": str(r.get("schemeCode","")), "name": r.get("schemeName","")} for r in results]}

@app.get("/api/search/stock")
async def api_search_stock(q: str):
    return {"results": search_stocks(q)}

@app.get("/api/nav/{code}")
async def api_nav(code: str):
    nav, nav_date = nav_latest(code)
    if not nav: raise HTTPException(404, f"NAV not found for {code}")
    return {"code": code, "nav": nav, "date": nav_date}

@app.get("/api/price/{symbol}")
async def api_price(symbol: str):
    price = stock_price(symbol)
    if not price: raise HTTPException(404, f"Price not found for {symbol}")
    return {"symbol": symbol, "price": price}

@app.get("/api/ping")
async def ping():
    return {"status": "ok", "version": "1.0", "message": "Nxance backend running"}

# ═══════════ SERVE FRONTEND ═══════════
@app.get("/", response_class=HTMLResponse)
async def root():
    path = os.path.join(os.path.dirname(__file__), "index.html")
    if os.path.exists(path):
        with open(path, encoding="utf-8") as f: return HTMLResponse(f.read())
    return HTMLResponse("""<html><body style='font-family:monospace;background:#05060D;color:#EEF0FF;padding:40px'>
    <h2 style='color:#00C9A7'>Nxance Backend Running ✓</h2>
    <p>Place index.html in same folder as main.py</p>
    <p><a href='/docs' style='color:#5BA3FF'>API Documentation → /docs</a></p>
    </body></html>""")

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))
    print(f"\n{'='*50}\n  Nxance Backend\n  Open: http://localhost:{port}\n  API docs: http://localhost:{port}/docs\n{'='*50}\n")
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=False, log_level="warning")
